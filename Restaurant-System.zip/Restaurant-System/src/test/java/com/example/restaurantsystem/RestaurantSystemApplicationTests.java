/*
package com.example.restaurantsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
*/
